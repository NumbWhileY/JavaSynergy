package com.example.laba4java;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


/**
 * Created by maxfad on 30.04.2017.
 */

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main3);
    }
}