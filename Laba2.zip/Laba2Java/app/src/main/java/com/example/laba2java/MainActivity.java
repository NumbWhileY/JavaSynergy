package com.example.laba2java;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonAdd , buttonMulti , buttonDivide , buttonMinus;
    EditText text1 , text2;
    TextView textv;
    int num1,num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonAdd = findViewById(R.id.btn_plus);
        buttonMulti = findViewById(R.id.btn_multi);
        buttonDivide = findViewById(R.id.btn_dvd);
        buttonMinus = findViewById(R.id.btn_minus);
        textv = findViewById(R.id.anser);
        text1 = findViewById(R.id.number1);
        text2 = findViewById(R.id.number2);

        buttonAdd.setOnClickListener(this);
        buttonMulti.setOnClickListener(this);
        buttonDivide.setOnClickListener(this);
        buttonMinus.setOnClickListener(this);

    }

    public int getIntFromText(EditText editText) {
        if (editText.getText().toString().isEmpty()) {
            Toast.makeText(this, "Enter Number", Toast.LENGTH_SHORT).show();
            return 0;
        } else
            return Integer.parseInt(editText.getText().toString());

    }


    @SuppressLint({"NonConstantResourceId", "SetTextI18n"})
    @Override
    public void onClick(@NonNull View view) {
        num1 = getIntFromText(text1);
        num2 = getIntFromText(text2);
        switch (view.getId()){
            case R.id.btn_plus:
                textv.setText("Answer " + (num1 + num2));
                break;

            case R.id.btn_minus:
                textv.setText("Answer " + (num1 - num2));
                break;

            case R.id.btn_multi:
                textv.setText("Answer " + (num1 * num2));
                break;

            case R.id.btn_dvd:
                textv.setText("Answer " + ((float)num1 / (float) num2));
                break;
       }
       }
}
